## MICKEY 2.0 ENCRYPTION

For testing purpose, you can use this command

`g++ -I . mickey.cpp example/example.cpp -o test-mickey`

`./test-mickey`
